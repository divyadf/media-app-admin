const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const LocalStorage = require('node-localstorage').LocalStorage;
const config = require('../config.js');
const jwt = require('jsonwebtoken');
localStorage = new LocalStorage('./scratch');
const MongoClient = require('mongodb').MongoClient;

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
const User = require('./User');

let db;
const mongourl = 'mongodb://127.0.0.1:27017/'
const col_name = 'products';
const bcrypt = require('bcryptjs');


// RETURNS ALL THE USERS IN THE DATABASE
router.get('/', function (req, res) {
    User.find({}, function (err, users) {
        if (err) return res.status(500).send("There was a problem finding the users.");
        res.status(200).send(users);
    });
});



// GETS A SINGLE USER FROM THE DATABASE
    router.get('/profile', function (req, res) {
        var token = localStorage.getItem('authtoken')
        console.log("token>>>",token)
        if (!token) {
            res.redirect('/')
        }
        jwt.verify(token, config.secret, function(err, decoded) {
        if (err) {
            res.redirect('/')
        };
            User.findById(decoded.id, { password: 0 }, function (err, user) {
                if (err) {res.redirect('/')}
                if (!user) {res.redirect('/')}
                db.collection(col_name).find().toArray((err,result) => {
                    if(err) throw err;
                    res.render('profile.ejs',{data:result, user})
                })
            });
        });
    });


    router.get('/usersList', function (req, res) {
        var token = localStorage.getItem('authtoken')
        console.log("token>>>",token)
        if (!token) {
            res.redirect('/')
        }
        jwt.verify(token, config.secret, function(err, decoded) {
        if (err) {
            res.redirect('/')
        };
            User.findById(decoded.id, { password: 0 }, function (err, user) {
                if (err) {res.redirect('/')}
                if (!user) {res.redirect('/')}
                db.collection('eduusers').find().toArray((err,result) => {
                    if(err) throw err;
                    res.render('users.ejs',{data:result, user})
                })
            });
        });
    });

// Post data from ui
router.post('/addData', (req,res) => {
    db.collection(col_name)
        // In Req.body we will recive the data
        // from form.
        .insert(req.body, (err,result) => {
            if(err) throw err;
            console.log('data.inserted');
        })
    res.redirect('/users/profile');
})

router.post('/addUser', (req, res) => {
    const hashedPassword = bcrypt.hashSync(req.body.password, 8);
    
    User.create({
      name : req.body.name,
      email : req.body.email,
      password : hashedPassword,
      role : req.body.role 
    },
    function (err, user) {
      if (err) return res.status(500).send("There was a problem registering the user.")
      // create a token
      var token = jwt.sign({ id: user._id }, config.secret, {
        expiresIn: 86400 // expires in 24 hours
      });
      const string = encodeURIComponent('Success Fully Register Please Login');
      res.redirect('/users/usersList');
    }); 
})

// Opening Add User page
router.get('/addProduct',(req,res) => {
    var token = localStorage.getItem('authtoken')
        console.log("token>>>",token)
        if (!token) {
            res.redirect('/')
        }
        jwt.verify(token, config.secret, function(err, decoded) {
        if (err) {
            res.redirect('/')
        };
            User.findById(decoded.id, { password: 0 }, function (err, user) {
                if (err) {res.redirect('/')}
                if (!user) {res.redirect('/')}
                db.collection(col_name).find().toArray((err,result) => {
                    if(err) throw err;
                    res.render('admin.ejs',{data:result, user})
                })
            });
        });
})

// Opening Add User page
router.get('/userAdd',(req,res) => {
    var token = localStorage.getItem('authtoken')
        console.log("token>>>",token)
        if (!token) {
            res.redirect('/')
        }
        jwt.verify(token, config.secret, function(err, decoded) {
        if (err) {
            res.redirect('/')
        };
            User.findById(decoded.id, { password: 0 }, function (err, user) {
                if (err) {res.redirect('/')}
                if (!user) {res.redirect('/')}
                db.collection(col_name).find().toArray((err,result) => {
                    if(err) throw err;
                    res.render('user.ejs',{data:result, user})
                })
            });
        });
})


router.get('/signup',  (req, res) => {
    res.render('signup.ejs')
 });

 router.get('/logout', (req,res) => {
     localStorage.removeItem('authtoken');
     res.redirect('/');
 })



 MongoClient.connect(mongourl,(err,client) => {
    if(err) throw err;
    db = client.db('admin')
})

module.exports = router;